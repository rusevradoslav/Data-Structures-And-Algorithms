package implementations;

public class Node<E> {
}
